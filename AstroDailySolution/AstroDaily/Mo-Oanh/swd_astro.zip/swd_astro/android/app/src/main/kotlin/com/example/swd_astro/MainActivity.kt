package com.example.swd_astro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
